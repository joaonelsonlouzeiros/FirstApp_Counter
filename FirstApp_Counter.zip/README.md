# Contador Android

Nome: João Nelson Louzeiros de Souza

## Como funciona

O valor do contador é guardado usando `remember { mutableStateOf(0) }`. Quando um dos botões altera esse valor, o Compose percebe a mudança de estado e atualiza automaticamente a parte da tela que mostra o número. O botão Aumentar soma 1, o botão Decrementar subtrai 1 e o botão Resetar volta o contador para 0.

## Desafios implementados

- D1 - O contador não fica negativo e o botão Decrementar fica desabilitado quando o valor está em 0.
- D2 - Botão Resetar usando `TextButton`.
