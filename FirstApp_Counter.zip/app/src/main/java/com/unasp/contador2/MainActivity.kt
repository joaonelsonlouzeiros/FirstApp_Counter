package com.unasp.contador2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.unasp.contador2.ui.theme.Contador2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Contador2Theme {
                ContadorScreen()
            }
        }
    }
}
