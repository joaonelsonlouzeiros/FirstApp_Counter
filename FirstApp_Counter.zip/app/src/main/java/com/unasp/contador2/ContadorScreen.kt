package com.unasp.contador2

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unasp.contador2.ui.theme.Contador2Theme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContadorScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Contador") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .padding(40.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SystemCounter()
        }
    }
}

@Composable
fun Counter(value: Int) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Valor atual",
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = value.toString(),
            modifier = Modifier.fillMaxWidth(),
            fontSize = 44.sp,
            fontWeight = FontWeight.Normal,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun SystemCounter() {
    var contador by remember { mutableStateOf(0) }

    Counter(contador)

    Button(
        onClick = { contador += 1 },
        modifier = Modifier.width(250.dp),
        shape = RoundedCornerShape(15.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary
        )
    ) {
        Text(
            text = "Aumentar",
            fontSize = 20.sp
        )
    }

    Button(
        onClick = { contador -= 1 },
        enabled = contador > 0,
        modifier = Modifier.width(250.dp),
        shape = RoundedCornerShape(15.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error
        )
    ) {
        Text(
            text = "Decrementar",
            fontSize = 20.sp
        )
    }

    TextButton(
        onClick = { contador = 0 }
    ) {
        Text(
            text = "Resetar",
            fontSize = 18.sp
        )
    }
}

@Preview(showBackground = true)
@Composable
fun ContadorScreenPreview() {
    Contador2Theme {
        ContadorScreen()
    }
}
